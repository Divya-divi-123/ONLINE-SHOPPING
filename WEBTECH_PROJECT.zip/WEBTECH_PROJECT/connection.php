<?php 
 $connect=mysqli_connect("localhost","root","Welcome-123","data");
 ?>