<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .text{
            display:flex;
            justify-content: center;
            align-items: center;
            background-color: skyblue;
            border-radius: 25px;
            border: 2px solid brown;
            margin-top: 100px;
            height: 200px;
            font-size: 1cm;
        }
        a{
            margin:100px 0px 0px 500px;
        }
    </style>
</head>
<body>

<div class="text">
<?php
ini_set("display_errors",1);
ini_set("display_startup_errors",1);
error_reporting(E_ALL);
include 'connection.php';
/*if($connect){
    echo "CONNECTION ESTABLISHED";
}
else{
   echo 'connection not established';
}*/
$fname = $_POST['fname'];
$sname = $_POST['sname'];
$email = $_POST['email'];
$pass  = $_POST['password'];
$cpass = $_POST['cpass'];
$query = "INSERT INTO form VALUES('$fname','$sname','$email','$pass','$cpass')";
$check=mysqli_query($connect,$query);
if($check)
{
    echo "ACCOUNT CREATED SUCCESSFULLY!GO BACK AND LOGIN";
}
else{
    echo "record not inserted successfully".mysqli_error($connect);
}
?>
</div>
<a href="login.php" class="btn btn-primary">GO BACK</a>
</body>
</html>