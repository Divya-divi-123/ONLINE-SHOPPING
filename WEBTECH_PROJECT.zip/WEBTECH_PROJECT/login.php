<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
body{
	background-image:url('image5.jpg');
	background-size:100%;
}
</style>
<script>
    let form=document.getElementById('form');
	let email=document.getElementById("mail");
    let pass=document.getElementById("pwd");
	let merror2=document.getElementById('merror');
    let perror2=document.getElementById('perror');
        form.addEventListener("submit",event=>{event.preventDefault();validate();})
        function validate(){
			let emai=email.value.trim();
        	let psd=pass.value.trim();
			if(emai==""){
                	merror2.innerText="email cant be empty";
            }
            else if(!(emai.match(/^[a-zA-Z0-9_/.-]+@[a-zA-Z0-9_-]+(?:\.[a-z]{2,6})$/))){
                merror2.innerText="invalid mail";
			}
           	else if(!(psd.match(/[a-z]+[A-Z]+[0-9]+/) || (/[A-Z]+[a-z]+[0-9]/))){
                perror2.innerText="must used aleast one capital,small,digit";
           	}
           	else if(!psd.match(/[#_@$^%]/)){
                perror2.innerText="contain atleast one special character";
			}
			else{
       	        form.submit();
       	   	}
	}
</script>
</head>
<body>
<p id="demo"></p>
<form action="login.php" method="POST" id="form">
<div class="container">
<h3 align="center" class="pt-3">LOG IN</h3>
<div class="row">
<div class="col-md-4"></div>
<div class="col-md-4 pt-5">
<div class="card">
<div class="card-body">
<label for="mail" class="mt-2 form-label text-info">email:</label>
<input id="mail" type="email" name="ename" class="form-control">
<span id="merror"></span><br>
<label for="pwd" class="mt-2 form-label text-info"">password:</label>
<input id="pwd" type="password" name="pwd" class="form-control">
<span id="perror"></span><br>
<?php
	ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
	error_reporting(E_ALL);

	if(isset($_POST['btn'])){

	$email = $_POST['ename'];
	$pwd = $_POST['pwd'];

	include 'connection.php';
	
	$query="SELECT * FROM form";
	$check=mysqli_query($connect,$query);
	
	if(mysqli_num_rows($check)){
		$count = 0;
		while($row=mysqli_fetch_assoc($check)){
			if($row['emailid']==$email
			){
 				$count = 1;
			}
			else{
				$count = $count;
			}
		}
		if($count == 1){
			$query1="SELECT pass from form WHERE emailid='$email'";
			$check1=mysqli_query($connect,$query1);
			$result1=mysqli_fetch_assoc($check1);
			if($result1['pass']==$pwd){
				header("Location:BOOTSTRAP/home.html");
				exit;
			}
			else{
				echo "PASSWORD NOT CORRECT";
			}
		}
		else{
			echo "USER DOESN'T EXIST";
		}			
	}
}
?>
<button type="submit"  class="mt-2 btn btn-info text-dark" name="btn" id="btn">submit</button>
</form>
</div>
</div>
</div>
</div>
</div>
</body>
</html>